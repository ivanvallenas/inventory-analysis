Welcome to inventory-analysis !

This is a Python package for inventory analysis and management. It allows you to make graphics about inventory and test the performance of different inventory policies.

The theoric base for this package is the book:
    Inventory and Production Management in Supply Chains 4th Edición
    de Edward A. Silver (Author), David F. Pyke (Author), Douglas J. Thomas (Author)
    https://www.amazon.com/Inventory-Production-Management-Supply-Chains/dp/146655861X