Welcome to inventory-analysis !

This is a Python package for inventory analysis and management. It allows you to make graphics about inventory and test the performance of different inventory politics.

