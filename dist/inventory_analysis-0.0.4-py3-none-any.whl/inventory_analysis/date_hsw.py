print("Hello world")
import webbrowser

url = 'https://www.youtube.com/'
webbrowser.open(url)